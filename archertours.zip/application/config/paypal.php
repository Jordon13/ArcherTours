<?php  
if (!defined('BASEPATH')) exit('No direct script access allowed');
 
 
$config['paypal_dev_client_id'] = 'AW9QGXgLkt37Ol-1OEkB5Ydu18x0xCRqJi_9v5kVExxVq_P6vBPa74vuN7n44l2yLmGO7G5KB9WlTmc5';
$config['paypal_dev_client_secret'] = 'EF_5XiFwl_umCTqosi9BQ3YZopg10Xa-OltT3kzOEkpddBv0lEYTM3udeGP6HOV7QGJun-LM0MQrXADz';
$config['paypal_client_id'] = 'My website';
$config['paypal_client_secret'] = 'smtp';
$config['paypal_dev_client_email'] = 'sb-pyawq43018@business.example.com';
$config['paypal_client_email'] = 'sb-pyawq43018@business.example.com';
