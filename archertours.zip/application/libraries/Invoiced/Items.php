<?php

namespace Models\Invoiced;

class Items{

    public $name;

    public $quantity = 0;

    public $unit_cost = 0.00;

    public $description;

}

?>