<?php

namespace Models\Invoiced;

if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class InvoiceFields{
    
    public $tax = "%";

    public $discount = false;

    public $shipping = false;

}

?>